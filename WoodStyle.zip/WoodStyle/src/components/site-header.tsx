import { useState } from "react";
import { Link } from "@tanstack/react-router";
import * as Dialog from "@radix-ui/react-dialog";
import { Menu, X } from "lucide-react";
import { brand, nav } from "@/lib/content";
import { Cta } from "@/components/cta";

export function SiteHeader() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40">
      <div className="h-0.5 bg-ember" aria-hidden="true" />
      <div className="bg-walnut px-5 py-2 text-center text-sm text-paper">
        Weihnachten naht — Unikate rechtzeitig{" "}
        <Link to="/kontakt" className="underline decoration-paper/40 underline-offset-4 hover:decoration-paper">
          anfragen
        </Link>
        .
      </div>
      <div className="border-b border-line bg-paper/90 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-5 md:px-8">
          <Link to="/" className="flex items-center gap-3" aria-label="WoodStyle, Startseite">
            <img
              src="/images/logo.webp"
              alt=""
              width={40}
              height={40}
              className="size-10 rounded-md object-cover"
            />
            <span className="font-display text-2xl leading-none">{brand.name}</span>
          </Link>

          <nav className="hidden items-center gap-7 md:flex" aria-label="Hauptnavigation">
            {nav.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                activeOptions={{ exact: item.exact }}
                inactiveProps={{
                  className: "text-sm text-mute transition-colors hover:text-ink",
                }}
                activeProps={{
                  className: "text-sm text-ink",
                  "aria-current": "page",
                }}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="hidden md:block">
            <Cta to="/kontakt" variant="ghost" className="px-5">
              Anfragen
            </Cta>
          </div>

          <Dialog.Root open={open} onOpenChange={setOpen}>
            <Dialog.Trigger asChild>
              <button
                type="button"
                className="inline-flex size-11 items-center justify-center rounded-full border border-line md:hidden"
                aria-label={open ? "Menü schließen" : "Menü öffnen"}
              >
                <Menu className="size-5" aria-hidden="true" />
              </button>
            </Dialog.Trigger>
            <Dialog.Portal>
              <Dialog.Overlay className="fixed inset-0 z-50 bg-ink/30" />
              <Dialog.Content className="fixed inset-0 z-50 flex flex-col bg-paper px-6 pt-5 pb-10">
                <div className="flex items-center justify-between">
                  <Dialog.Title className="font-display text-2xl">{brand.name}</Dialog.Title>
                  <Dialog.Description className="sr-only">Seitennavigation</Dialog.Description>
                  <Dialog.Close asChild>
                    <button
                      type="button"
                      className="inline-flex size-11 items-center justify-center rounded-full border border-line"
                      aria-label="Menü schließen"
                    >
                      <X className="size-5" aria-hidden="true" />
                    </button>
                  </Dialog.Close>
                </div>
                <nav className="mt-12 flex flex-col gap-2" aria-label="Mobilnavigation">
                  {nav.map((item) => (
                    <Link
                      key={item.to}
                      to={item.to}
                      activeOptions={{ exact: item.exact }}
                      onClick={() => setOpen(false)}
                      inactiveProps={{
                        className: "border-b border-line py-3 font-display text-4xl text-mute",
                      }}
                      activeProps={{
                        className: "border-b border-line py-3 font-display text-4xl text-ink",
                      }}
                    >
                      {item.label}
                    </Link>
                  ))}
                </nav>
                <div className="mt-auto">
                  <Cta to="/kontakt" className="w-full" onClick={() => setOpen(false)}>
                    Anfrage starten
                  </Cta>
                </div>
              </Dialog.Content>
            </Dialog.Portal>
          </Dialog.Root>
        </div>
      </div>
    </header>
  );
}
