import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";

const styles = {
  solid: "bg-ember text-paper hover:bg-ember-deep",
  ghost: "border border-ink/15 bg-transparent text-ink hover:border-ink/40",
  paper: "bg-paper text-ink hover:bg-sand",
  quiet: "bg-transparent px-0 text-ink underline decoration-ink/25 underline-offset-4 hover:text-ember hover:decoration-ember",
} as const;

type Variant = keyof typeof styles;

type Internal =
  | "/"
  | "/katalog"
  | "/ueber-uns"
  | "/versand"
  | "/kontakt"
  | "/impressum"
  | "/datenschutz";

export function Cta({
  to,
  href,
  hash,
  variant = "solid",
  children,
  className = "",
  onClick,
}: {
  to?: Internal;
  href?: string;
  hash?: string;
  variant?: Variant;
  children: ReactNode;
  className?: string;
  onClick?: () => void;
}) {
  const cls = `inline-flex min-h-11 items-center justify-center rounded-full px-6 text-sm font-medium transition-colors ${styles[variant]} ${className}`;

  if (href) {
    const external = href.startsWith("http");
    return (
      <a
        href={href}
        className={cls}
        onClick={onClick}
        {...(external ? { target: "_blank", rel: "noopener noreferrer" } : {})}
      >
        {children}
      </a>
    );
  }

  return (
    <Link to={to ?? "/"} hash={hash} className={cls} onClick={onClick}>
      {children}
    </Link>
  );
}
