import { Link } from "@tanstack/react-router";
import { brand } from "@/lib/content";

const links = [
  { to: "/katalog", label: "Katalog" },
  { to: "/ueber-uns", label: "Über uns" },
  { to: "/versand", label: "Versand & Zahlung" },
  { to: "/kontakt", label: "Kontakt" },
  { to: "/impressum", label: "Impressum" },
  { to: "/datenschutz", label: "Datenschutz" },
] as const;

export function SiteFooter() {
  return (
    <footer className="border-t border-line bg-paper">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 md:grid-cols-3 md:px-8">
        <div>
          <p className="font-display text-3xl">{brand.name}</p>
          <p className="mt-3 max-w-xs text-sm text-mute">
            Handgefertigte Brandmalerei und Holzdesign aus {brand.city}.
          </p>
        </div>
        <nav aria-label="Fußzeile" className="flex flex-col gap-2 text-sm">
          {links.map((item) => (
            <Link key={item.to} to={item.to} className="text-mute hover:text-ink">
              {item.label}
            </Link>
          ))}
        </nav>
        <address className="text-sm text-mute not-italic">
          <p className="text-ink">{brand.owner}</p>
          <p className="mt-2">
            {brand.street}
            <br />
            {brand.zip} {brand.city}
          </p>
          <p className="mt-3">
            <a className="hover:text-ember" href={`tel:${brand.phoneTel}`}>
              {brand.phonePretty}
            </a>
            <br />
            <a className="hover:text-ember" href={`mailto:${brand.email}`}>
              {brand.email}
            </a>
          </p>
        </address>
      </div>
      <div className="border-t border-line">
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-5 py-5 text-xs text-mute md:flex-row md:justify-between md:px-8">
          <p>© 2026 {brand.name}. Alle Rechte vorbehalten.</p>
          <p>{brand.vatNote}</p>
        </div>
      </div>
    </footer>
  );
}

export function WhatsappFab() {
  return (
    <a
      href="https://wa.me/4915232161777"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed right-4 bottom-4 z-30 inline-flex min-h-11 items-center gap-2 rounded-full bg-ember px-4 text-sm font-medium text-paper shadow-lift md:hidden"
    >
      Anfragen
    </a>
  );
}
