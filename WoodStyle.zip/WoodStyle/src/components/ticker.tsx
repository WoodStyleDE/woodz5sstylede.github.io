import { ticker } from "@/lib/content";

export function Ticker() {
  return (
    <div className="marquee" aria-hidden="true">
      <div className="marquee-track flex w-max">
        {[0, 1].map((copy) => (
          <div key={copy} className={copy === 1 ? "marquee-clone flex" : "flex"}>
            {ticker.map((item) => (
              <span
                key={`${copy}-${item}`}
                className="px-5 py-3.5 text-xs font-medium tracking-kicker text-mute uppercase"
              >
                {item}
                <span className="ml-5 text-ember">·</span>
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
