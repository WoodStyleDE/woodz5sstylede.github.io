import type { ErrorComponentProps } from "@tanstack/react-router";

const FALLBACK_MESSAGE = "Ein unerwarteter Fehler ist aufgetreten. Laden Sie die Seite neu.";

function errorMessage(error: unknown): string {
  if (error instanceof Error && error.message) return error.message;
  if (typeof error === "string" && error) return error;
  return FALLBACK_MESSAGE;
}

export function AppErrorComponent({ error }: ErrorComponentProps) {
  return (
    <section className="flex min-h-[70vh] flex-col items-center justify-center gap-3 bg-paper px-6 text-center text-ink">
      <h1 className="font-display text-4xl">Etwas ist schiefgelaufen</h1>
      <p className="max-w-md text-sm break-words text-mute">{errorMessage(error)}</p>
    </section>
  );
}
