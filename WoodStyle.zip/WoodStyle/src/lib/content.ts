export const brand = {
  name: "WoodStyle",
  owner: "Olena Perebykivska",
  street: "Bahnhofstraße 11",
  zip: "35781",
  city: "Weilburg",
  country: "Deutschland",
  email: "woodstylede@gmail.com",
  phonePretty: "+49 1523 2161777",
  phoneTel: "+4915232161777",
  telegram: "https://t.me/woodstylede",
  vatNote: "Gemäß § 19 UStG wird keine Umsatzsteuer berechnet und ausgewiesen.",
} as const;

export function whatsapp(text?: string) {
  const base = "https://wa.me/4915232161777";
  if (!text) return base;
  return `${base}?text=${encodeURIComponent(text)}`;
}

export type Product = {
  id: "bilder" | "schneidebretter" | "untersetzer" | "sonstiges";
  title: string;
  kicker: string;
  price: string;
  blurb: string;
  detail: string;
  image: string;
  width: number;
  height: number;
  alt: string;
  inquiry: string;
};

export const products: Product[] = [
  {
    id: "bilder",
    title: "Bilder & Porträts",
    kicker: "Signatur",
    price: "ab 45 €",
    blurb: "Ein Gesicht, ein Tier, ein Moment — mit dem Brennstift nach Ihrer Fotovorlage ins Holz gelegt.",
    detail:
      "Präzise Brandmalerei auf edlem Holz nach Ihrer persönlichen Fotovorlage. Das Motiv wird nicht gedruckt, sondern Linie für Linie eingebrannt — das Geschenk, das man in die Hand nimmt.",
    image: "/images/portrait.jpg",
    width: 900,
    height: 1200,
    alt: "Brandmalerei eines Hundes auf einer hellen Holztafel, an eine warme Wand gelehnt",
    inquiry: "Hallo, ich interessiere mich für Brandmalerei.",
  },
  {
    id: "schneidebretter",
    title: "Schneidebretter",
    kicker: "Für die Küche",
    price: "ab 25 €",
    blurb: "Dicke Bretter aus Hartholz, mit einem Motiv, das zum Stück gehört und im Alltag bleibt.",
    detail:
      "Massivholz-Schneidebretter aus hochwertigem Hartholz, langlebig und messerschonend verarbeitet. Auf Wunsch mit Namen, Datum oder einem kleinen eingebrannten Zweig.",
    image: "/images/board.jpg",
    width: 1400,
    height: 1050,
    alt: "Massives Eichen-Schneidebrett mit eingebranntem Olivenzweig auf einem Walnusstisch",
    inquiry: "Hallo, ich interessiere mich für Schneidebretter.",
  },
  {
    id: "untersetzer",
    title: "Untersetzer",
    kicker: "Für den Tisch",
    price: "ab 15 €",
    blurb: "Runde Holzscheiben mit feiner Gravur — einzeln oder als Satz, ruhig und griffig.",
    detail:
      "Stilvolle Holz-Untersetzer für Gläser und Tassen, verziert mit feiner Brandgravur. Jahresringe, ein Blatt, ein Monogramm: klein, aber ganz Ihr eigenes.",
    image: "/images/coasters.jpg",
    width: 1400,
    height: 1050,
    alt: "Vier runde Walnuss-Untersetzer mit eingebrannten Jahresringen auf Leinen",
    inquiry: "Hallo, ich interessiere mich für Untersetzer.",
  },
  {
    id: "sonstiges",
    title: "Sonstiges",
    kicker: "Kleine Stücke",
    price: "ab 10 €",
    blurb: "Anhänger, Holzscheiben, kleine Zeichen — wenn das Geschenk in die Handfläche passen soll.",
    detail:
      "Kreative Holzdekorationen, individuelle Schlüsselanhänger und maßgefertigte Souvenirs. Sagen Sie uns die Idee, wir sagen Ihnen, was das Holz hergibt.",
    image: "/images/gifts.jpg",
    width: 1400,
    height: 1050,
    alt: "Kleine Holzgeschenke mit Brandmalerei auf einer Werkbank: Scheibe, Anhänger und Herz",
    inquiry: "Hallo, ich interessiere mich für Holzdekorationen.",
  },
];

export const steps = [
  {
    n: "01",
    title: "Anfrage",
    text: "Schreiben Sie uns Produkt und Idee, gern mit Foto — per WhatsApp, Telegram oder E-Mail.",
  },
  {
    n: "02",
    title: "Abstimmung",
    text: "Wir besprechen Motiv, Holz und Größe und schicken ein unverbindliches Angebot.",
  },
  {
    n: "03",
    title: "Zahlung",
    text: "Per PayPal oder Banküberweisung. Die Fertigung beginnt nach Zahlungseingang.",
  },
  {
    n: "04",
    title: "Fertigung & Versand",
    text: "Ihr Unikat entsteht von Hand und geht per DHL mit Sendungsverfolgung auf den Weg.",
  },
] as const;

export const pillars = [
  {
    n: "01",
    title: "Massivholz",
    text: "Nur ausgewählte, natürliche Hölzer — die Maserung bleibt sichtbar und gehört zum Bild.",
  },
  {
    n: "02",
    title: "Von Hand",
    text: "Jedes Detail wird gefertigt und mit dem Brennstift eingebrannt, nicht aufgedruckt.",
  },
  {
    n: "03",
    title: "Ein Unikat",
    text: "Kein zweites Stück fällt gleich aus. Deshalb eignet es sich als Geschenk, das man behält.",
  },
] as const;

export const ticker = [
  "Brandmalerei",
  "Massivholz",
  "Unikate",
  "Weilburg",
  "Nach Foto",
  "DHL Versand",
  "PayPal",
  "Überweisung",
] as const;

export const nav = [
  { to: "/", label: "Startseite", exact: true },
  { to: "/katalog", label: "Katalog", exact: false },
  { to: "/ueber-uns", label: "Über uns", exact: false },
  { to: "/versand", label: "Versand", exact: false },
  { to: "/kontakt", label: "Kontakt", exact: false },
] as const;
