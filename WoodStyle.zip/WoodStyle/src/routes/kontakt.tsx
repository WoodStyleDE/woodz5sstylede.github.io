import { createFileRoute } from "@tanstack/react-router";
import { brand, steps, whatsapp } from "@/lib/content";

export const Route = createFileRoute("/kontakt")({
  head: () => ({
    meta: [
      { title: "Kontakt & Bestellung · WoodStyle" },
      {
        name: "description",
        content:
          "WoodStyle anfragen: per WhatsApp, Telegram, E-Mail oder Telefon. Individuelle Holzprodukte und Brandmalerei aus Weilburg.",
      },
    ],
  }),
  component: Contact,
});

const channels = [
  { label: "WhatsApp", value: "Nachricht schreiben", href: whatsapp() },
  { label: "Telegram", value: "@woodstylede", href: brand.telegram },
  { label: "E-Mail", value: brand.email, href: `mailto:${brand.email}?subject=Anfrage%20WoodStyle` },
  { label: "Telefon", value: brand.phonePretty, href: `tel:${brand.phoneTel}` },
];

function Contact() {
  return (
    <div className="mx-auto max-w-6xl px-5 pt-12 pb-20 md:px-8 md:pt-16">
      <p className="text-xs font-medium tracking-kicker text-ember uppercase">Kontakt</p>
      <h1 className="mt-3 max-w-3xl font-display text-section">Sagen Sie uns, was ins Holz soll</h1>
      <p className="mt-4 max-w-2xl text-lg text-mute">
        Eine Zeile reicht für den Anfang. Foto, Größe und Anlass helfen uns, das Angebot genauer zu machen.
      </p>

      <div className="mt-12 grid gap-12 lg:grid-cols-12">
        <ul className="lg:col-span-7">
          {channels.map((channel) => (
            <li key={channel.label} className="border-t border-line">
              <a
                href={channel.href}
                className="group flex min-h-20 items-center justify-between gap-4 py-4"
                {...(channel.href.startsWith("http")
                  ? { target: "_blank", rel: "noopener noreferrer" }
                  : {})}
              >
                <span>
                  <span className="block text-xs tracking-kicker text-mute uppercase">{channel.label}</span>
                  <span className="mt-1 block font-display text-2xl group-hover:text-ember md:text-3xl">
                    {channel.value}
                  </span>
                </span>
                <span className="text-ember" aria-hidden="true">
                  →
                </span>
              </a>
            </li>
          ))}
        </ul>

        <aside className="rounded-xl bg-sand p-8 lg:col-span-5">
          <h2 className="font-display text-3xl">Das hilft bei der Anfrage</h2>
          <ol className="mt-6 space-y-4 text-mute">
            <li>
              <span className="font-display text-ember">01 </span>
              Gewünschtes Produkt und ungefähre Größe
            </li>
            <li>
              <span className="font-display text-ember">02 </span>
              Motiv oder Foto als Vorlage
            </li>
            <li>
              <span className="font-display text-ember">03 </span>
              Anlass und gewünschter Zeitpunkt
            </li>
          </ol>
          <p className="mt-8 inline-flex items-center gap-2 rounded-full bg-paper px-4 py-2 text-sm text-mute">
            <span className="size-2 rounded-full bg-ember" aria-hidden="true" />
            Antwort in der Regel innerhalb von 2 Stunden
          </p>
        </aside>
      </div>

      <ol className="mt-20 grid gap-8 border-t border-line pt-12 md:grid-cols-4">
        {steps.map((step) => (
          <li key={step.n}>
            <span className="font-display text-3xl text-ember">{step.n}</span>
            <h2 className="mt-2 font-display text-2xl">{step.title}</h2>
            <p className="mt-2 text-sm text-mute">{step.text}</p>
          </li>
        ))}
      </ol>
    </div>
  );
}
