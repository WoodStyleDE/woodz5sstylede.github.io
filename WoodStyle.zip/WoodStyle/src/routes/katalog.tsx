import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Cta } from "@/components/cta";
import { brand, products, whatsapp, type Product } from "@/lib/content";

export const Route = createFileRoute("/katalog")({
  head: () => ({
    meta: [
      { title: "Katalog · WoodStyle" },
      {
        name: "description",
        content:
          "Katalog von WoodStyle: Massivholz-Schneidebretter, Untersetzer, Porträts in Brandmalerei und individuelle Holzdekorationen.",
      },
    ],
  }),
  component: Katalog,
});

const filters = [
  { id: "alle", label: "Alles" },
  ...products.map((item) => ({ id: item.id, label: item.title })),
] as const;

function Katalog() {
  const [active, setActive] = useState<(typeof filters)[number]["id"]>("alle");
  const shown = active === "alle" ? products : products.filter((item) => item.id === active);

  return (
    <div className="mx-auto max-w-6xl px-5 pt-12 pb-20 md:px-8 md:pt-16">
      <p className="text-xs font-medium tracking-kicker text-ember uppercase">Katalog</p>
      <h1 className="mt-3 max-w-3xl font-display text-section">Jedes Stück ein Unikat</h1>
      <p className="mt-4 max-w-2xl text-lg text-mute">
        Fragen Sie Ihr Wunschmotiv direkt an. Größe, Holz und Motiv stimmen wir danach gemeinsam ab —
        die Preise sind der Einstieg, nicht das fertige Angebot.
      </p>

      <div className="mt-8 flex flex-wrap gap-2" role="group" aria-label="Kategorien">
        {filters.map((filter) => {
          const pressed = active === filter.id;
          return (
            <button
              key={filter.id}
              type="button"
              aria-pressed={pressed}
              onClick={() => setActive(filter.id)}
              className={
                pressed
                  ? "min-h-11 rounded-full bg-ink px-5 text-sm text-paper"
                  : "min-h-11 rounded-full border border-line bg-paper px-5 text-sm text-ink hover:border-ink/30"
              }
            >
              {filter.label}
            </button>
          );
        })}
      </div>

      <div className="mt-6">
        {shown.map((item, index) => (
          <ProductRow key={item.id} item={item} flip={index % 2 === 1} />
        ))}
      </div>

      <p className="mt-10 text-sm text-mute">{brand.vatNote}</p>
    </div>
  );
}

function ProductRow({ item, flip }: { item: Product; flip: boolean }) {
  return (
    <article
      id={item.id}
      className="grid scroll-mt-36 items-center gap-8 border-t border-line py-12 lg:grid-cols-2 lg:gap-14"
    >
      <div className={flip ? "overflow-hidden rounded-xl lg:order-2" : "overflow-hidden rounded-xl"}>
        <img
          src={item.image}
          alt={item.alt}
          width={item.width}
          height={item.height}
          className="aspect-4/3 w-full object-cover"
        />
      </div>
      <div>
        <p className="text-xs font-medium tracking-kicker text-ember uppercase">{item.kicker}</p>
        <h2 className="mt-3 font-display text-4xl">{item.title}</h2>
        <p className="mt-4 text-lg text-mute">{item.detail}</p>
        <p className="mt-6 font-display text-3xl text-ember">{item.price}</p>
        <div className="mt-6">
          <Cta href={whatsapp(item.inquiry)}>Per WhatsApp anfragen</Cta>
        </div>
      </div>
    </article>
  );
}
