import { createFileRoute } from "@tanstack/react-router";
import { Cta } from "@/components/cta";

export const Route = createFileRoute("/versand")({
  head: () => ({
    meta: [
      { title: "Versand & Zahlung · WoodStyle" },
      {
        name: "description",
        content:
          "DHL-Versand mit Sendungsverfolgung sowie Zahlung per PayPal oder Banküberweisung bei WoodStyle.",
      },
    ],
  }),
  component: Shipping,
});

function Shipping() {
  return (
    <div className="mx-auto max-w-6xl px-5 pt-12 pb-20 md:px-8 md:pt-16">
      <p className="text-xs font-medium tracking-kicker text-ember uppercase">Versand & Zahlung</p>
      <h1 className="mt-3 max-w-3xl font-display text-section">Klar, bevor die Arbeit beginnt</h1>
      <p className="mt-4 max-w-2xl text-lg text-mute">
        Keine Überraschung an der Kasse. Versand und Zahlung stehen fest, die Fertigung startet erst,
        wenn die Zahlung da ist.
      </p>

      <div className="mt-12 grid gap-px overflow-hidden rounded-xl border border-line bg-line md:grid-cols-2">
        <section className="bg-paper p-8 md:p-12">
          <p className="font-display text-5xl text-ember">DHL</p>
          <h2 className="mt-4 font-display text-3xl">Versand in Deutschland</h2>
          <p className="mt-4 text-mute">
            Der Versand erfolgt mit DHL innerhalb Deutschlands. Zu jeder Sendung gibt es eine
            Sendungsverfolgungsnummer, damit das Paket unterwegs sichtbar bleibt.
          </p>
        </section>
        <section className="bg-sand p-8 md:p-12">
          <p className="font-display text-5xl text-ember">€</p>
          <h2 className="mt-4 font-display text-3xl">Zwei Zahlungswege</h2>
          <p className="mt-4 text-mute">
            Sie zahlen per PayPal oder per Banküberweisung (Vorkasse). Beides ist unkompliziert, und
            erst der Zahlungseingang startet die Fertigung Ihres Unikats.
          </p>
        </section>
      </div>

      <div className="mt-12">
        <Cta to="/kontakt">Bestellung anfragen</Cta>
      </div>
    </div>
  );
}
