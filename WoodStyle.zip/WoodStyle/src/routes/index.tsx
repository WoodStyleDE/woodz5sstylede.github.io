import { createFileRoute, Link } from "@tanstack/react-router";
import { Cta } from "@/components/cta";
import { Ticker } from "@/components/ticker";
import { brand, pillars, products, steps, whatsapp } from "@/lib/content";

const featured = products[0];
const rest = products.slice(1);

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "WoodStyle – Brandmalerei & Holzdesign aus Weilburg" },
      {
        name: "description",
        content:
          "Handgemachte Brandmalerei und Holzdesign aus Weilburg: Porträts nach Foto, Schneidebretter, Untersetzer und Holzdekorationen als persönliches Geschenk.",
      },
    ],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "LocalBusiness",
          name: "WoodStyle",
          description:
            "Handgefertigte Holzprodukte und individuelle Brandmalerei: Porträts, Schneidebretter, Untersetzer und Holzdekorationen.",
          url: "https://woodstyle.de/",
          email: brand.email,
          telephone: brand.phonePretty,
          address: {
            "@type": "PostalAddress",
            streetAddress: brand.street,
            postalCode: brand.zip,
            addressLocality: brand.city,
            addressCountry: "DE",
          },
          areaServed: "DE",
        }),
      },
    ],
  }),
  component: Home,
});

function Home() {
  return (
    <>
      <section className="mx-auto grid max-w-6xl items-end gap-10 px-5 pt-10 pb-14 md:px-8 lg:grid-cols-12 lg:pt-16 lg:pb-20">
        <div className="lg:col-span-5">
          <p className="text-xs font-medium tracking-kicker text-ember uppercase">
            Atelier in Weilburg
          </p>
          <h1 className="mt-4 font-display text-hero">
            Eingebrannt,
            <span className="italic text-ember"> nicht gedruckt.</span>
          </h1>
          <p className="mt-6 max-w-md text-lg text-mute">
            Porträts nach Ihrem Foto, Schneidebretter und kleine Holzstücke. In Weilburg von Hand
            gefertigt — jedes Motiv ein Unikat.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Cta to="/katalog">Katalog ansehen</Cta>
            <Cta to="/kontakt" variant="ghost">
              Motiv anfragen
            </Cta>
          </div>
          <p className="mt-8 text-sm text-mute">
            Handarbeit · PayPal oder Überweisung · DHL mit Sendungsverfolgung
          </p>
        </div>
        <figure className="lg:col-span-7">
          <div className="overflow-hidden rounded-xl">
            <img
              src="/images/hero.jpg"
              alt="Hände führen einen Brennstift über eine helle Holztafel in der Werkstatt"
              width={1600}
              height={1067}
              fetchPriority="high"
              className="aspect-3/2 w-full object-cover"
            />
          </div>
          <figcaption className="mt-3 flex items-center justify-between text-xs tracking-kicker text-mute uppercase">
            <span>Pyrografie · Werkbank</span>
            <span>Weilburg</span>
          </figcaption>
        </figure>
      </section>

      <Ticker />

      <section className="bg-sand">
        <div className="mx-auto max-w-6xl px-5 py-16 md:px-8 md:py-24">
          <div className="flex flex-wrap items-end justify-between gap-6">
            <div>
              <p className="text-xs font-medium tracking-kicker text-ember uppercase">01 — Katalog</p>
              <h2 className="mt-3 font-display text-section">Vier Richtungen, ein Brennstift</h2>
            </div>
            <Cta to="/katalog" variant="quiet" className="px-0">
              Alles im Katalog
            </Cta>
          </div>

          <article className="mt-12 grid items-center gap-8 lg:grid-cols-12 lg:gap-12">
            <Link
              to="/katalog"
              hash={featured.id}
              className="group overflow-hidden rounded-xl lg:col-span-7"
            >
              <img
                src={featured.image}
                alt={featured.alt}
                width={featured.width}
                height={featured.height}
                className="aspect-3/4 w-full object-cover transition-transform duration-700 group-hover:scale-105 sm:aspect-4/5"
              />
            </Link>
            <div className="lg:col-span-5">
              <p className="text-xs font-medium tracking-kicker text-ember uppercase">{featured.kicker}</p>
              <h3 className="mt-3 font-display text-4xl">{featured.title}</h3>
              <p className="mt-4 text-lg text-mute">{featured.blurb}</p>
              <p className="mt-6 font-display text-3xl text-ember">{featured.price}</p>
              <div className="mt-6 flex flex-wrap gap-3">
                <Cta href={whatsapp(featured.inquiry)}>Per WhatsApp anfragen</Cta>
                <Cta to="/katalog" hash={featured.id} variant="ghost">
                  Mehr dazu
                </Cta>
              </div>
            </div>
          </article>

          <div className="mt-14 grid gap-10 md:grid-cols-3">
            {rest.map((item) => (
              <article key={item.id}>
                <Link to="/katalog" hash={item.id} className="group block overflow-hidden rounded-xl">
                  <img
                    src={item.image}
                    alt={item.alt}
                    width={item.width}
                    height={item.height}
                    loading="lazy"
                    className="aspect-4/3 w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                </Link>
                <p className="mt-4 text-xs font-medium tracking-kicker text-ember uppercase">{item.kicker}</p>
                <h3 className="mt-2 font-display text-2xl">
                  <Link to="/katalog" hash={item.id} className="hover:text-ember">
                    {item.title}
                  </Link>
                </h3>
                <p className="mt-2 text-sm text-mute">{item.blurb}</p>
                <div className="mt-4 flex items-center justify-between gap-3">
                  <span className="font-display text-2xl text-ember">{item.price}</span>
                  <Cta href={whatsapp(item.inquiry)} variant="quiet" className="px-0">
                    WhatsApp
                  </Cta>
                </div>
              </article>
            ))}
          </div>
          <p className="mt-12 text-center text-xs text-mute">{brand.vatNote}</p>
        </div>
      </section>

      <section className="bg-walnut text-paper">
        <div className="mx-auto grid max-w-6xl md:grid-cols-3">
          {pillars.map((item) => (
            <div
              key={item.n}
              className="border-t border-paper/15 px-5 py-12 md:border-t-0 md:border-l md:px-8 md:first:border-l-0"
            >
              <p className="font-display text-4xl text-sand">{item.n}</p>
              <h2 className="mt-4 font-display text-3xl">{item.title}</h2>
              <p className="mt-3 text-paper/75">{item.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-16 md:px-8 md:py-24">
        <p className="text-xs font-medium tracking-kicker text-ember uppercase">02 — Ablauf</p>
        <h2 className="mt-3 max-w-xl font-display text-section">Von der Idee bis zur Sendung</h2>
        <ol className="mt-12 grid gap-10 md:grid-cols-4">
          {steps.map((step) => (
            <li key={step.n}>
              <span className="font-display text-4xl text-ember">{step.n}</span>
              <h3 className="mt-3 font-display text-2xl">{step.title}</h3>
              <p className="mt-2 text-sm text-mute">{step.text}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="mx-auto max-w-6xl px-5 pb-16 md:px-8 md:pb-24">
        <div className="relative">
          <img
            src="/images/atelier.jpg"
            alt="Ruhige Werkstatt mit gestapelten Holzbrettern und Nachmittagslicht"
            width={1600}
            height={1067}
            loading="lazy"
            className="aspect-video w-full rounded-xl object-cover"
          />
          <div className="relative z-10 -mt-16 ml-4 max-w-md rounded-xl bg-paper p-6 shadow-lift md:absolute md:right-8 md:bottom-8 md:left-auto md:mt-0 md:ml-0">
            <p className="text-xs font-medium tracking-kicker text-ember uppercase">Das Atelier</p>
            <h2 className="mt-2 font-display text-3xl">Wo das Holz noch warm wird</h2>
            <p className="mt-3 text-mute">
              Kein Lager, keine Serie. Ein Motiv, ein Stück Holz, und die Zeit, die der Brennstift braucht.
            </p>
            <Cta to="/ueber-uns" variant="quiet" className="mt-4 px-0">
              Über WoodStyle
            </Cta>
          </div>
        </div>
      </section>

      <section className="border-t border-line">
        <div className="mx-auto flex max-w-6xl flex-col items-start gap-8 px-5 py-16 md:flex-row md:items-end md:justify-between md:px-8 md:py-20">
          <div>
            <p className="text-xs font-medium tracking-kicker text-ember uppercase">03 — Kontakt</p>
            <h2 className="mt-3 max-w-xl font-display text-section">Schicken Sie uns das Motiv.</h2>
            <p className="mt-4 max-w-md text-mute">
              WhatsApp, Telegram oder E-Mail. Wir antworten in der Regel innerhalb von zwei Stunden.
            </p>
          </div>
          <div className="flex flex-wrap gap-3">
            <Cta href={whatsapp()}>WhatsApp</Cta>
            <Cta href={brand.telegram} variant="ghost">
              Telegram
            </Cta>
            <Cta href={`mailto:${brand.email}?subject=Anfrage%20WoodStyle`} variant="ghost">
              E-Mail
            </Cta>
          </div>
        </div>
      </section>
    </>
  );
}
