import { createFileRoute } from "@tanstack/react-router";
import { brand } from "@/lib/content";

export const Route = createFileRoute("/datenschutz")({
  head: () => ({
    meta: [
      { title: "Datenschutz · WoodStyle" },
      {
        name: "description",
        content:
          "Datenschutzerklärung von WoodStyle: Verarbeitung personenbezogener Daten und Ihre Rechte gemäß DSGVO.",
      },
    ],
  }),
  component: Privacy,
});

function Privacy() {
  return (
    <article className="legal mx-auto max-w-3xl px-5 pt-12 pb-20 md:px-8 md:pt-16">
      <p className="text-xs font-medium tracking-kicker text-ember uppercase">Rechtliches</p>
      <h1 className="mt-3 font-display text-section">Datenschutzerklärung</h1>

      <h2>1. Datenschutz auf einen Blick</h2>
      <p>
        Die folgenden Hinweise geben einen einfachen Überblick darüber, was mit Ihren personenbezogenen
        Daten passiert, wenn Sie unsere Website besuchen. Personenbezogene Daten sind alle Daten, mit
        denen Sie persönlich identifiziert werden können. Diese Website verwendet keine Cookies und keine
        Analyse- oder Tracking-Dienste.
      </p>

      <h2>2. Verantwortliche Stelle</h2>
      <p>Die verantwortliche Stelle für die Datenverarbeitung auf dieser Website ist:</p>
      <p>
        <strong className="text-ink">{brand.owner}</strong>
        <br />
        {brand.name}
        <br />
        {brand.street}
        <br />
        {brand.zip} {brand.city}
        <br />
        Telefon: {brand.phonePretty}
        <br />
        E-Mail: {brand.email}
      </p>

      <h2>3. Datenerfassung auf unserer Website</h2>
      <h3>Hosting</h3>
      <p>
        Beim Besuch der Website verarbeitet der Hosting-Anbieter technisch erforderliche Server-Logfiles
        (zum Beispiel IP-Adresse, Datum und Uhrzeit des Zugriffs, aufgerufene Seite und Browsertyp).
        Rechtsgrundlage ist unser berechtigtes Interesse an einer sicheren und effizienten Bereitstellung
        der Website (Art. 6 Abs. 1 lit. f DSGVO). Eine Übermittlung in ein Drittland kann je nach Standort
        des Anbieters nicht ausgeschlossen werden; sie erfolgt dann auf Grundlage eines
        Angemessenheitsbeschlusses oder geeigneter Garantien.
      </p>

      <h3>Schriftarten</h3>
      <p>
        Diese Website verwendet lokal eingebundene Schriftarten. Beim Aufruf der Seiten wird keine
        Verbindung zu Servern von Schriftanbietern hergestellt.
      </p>

      <h2>4. Kontaktaufnahme (Messenger, E-Mail, Telefon)</h2>
      <p>
        Wenn Sie uns per WhatsApp, Telegram, E-Mail oder Telefon kontaktieren, speichern und verarbeiten
        wir Ihre übermittelten Daten (z. B. Telefonnummer, Name, E-Mail-Adresse, übermittelte Fotos)
        ausschließlich zur Bearbeitung Ihrer Anfrage und zur Durchführung der Bestellung. Rechtsgrundlage
        ist Art. 6 Abs. 1 lit. b DSGVO (vorvertragliche Maßnahmen und Vertragserfüllung), im Übrigen unser
        berechtigtes Interesse an der Beantwortung Ihrer Anfrage (Art. 6 Abs. 1 lit. f DSGVO). Wir
        speichern Ihre Daten, solange es für die Bearbeitung erforderlich ist; gesetzliche
        Aufbewahrungsfristen bleiben unberührt. Die Links zu WhatsApp und Telegram auf dieser Website
        öffnen die jeweilige App bzw. Website des Anbieters; erst dann werden Daten an den Anbieter
        übermittelt.
      </p>

      <h3>WhatsApp</h3>
      <p>
        Anbieter ist die WhatsApp Ireland Limited, 4 Grand Canal Square, Grand Canal Harbour, Dublin 2,
        Irland. Details zur Datenverarbeitung finden Sie unter:{" "}
        <a href="https://www.whatsapp.com/legal/privacy-policy-eea" target="_blank" rel="noopener noreferrer">
          WhatsApp Datenschutz
        </a>
        .
      </p>

      <h3>Telegram</h3>
      <p>
        Anbieter ist die Telegram Messenger Inc. Details zur Datenverarbeitung finden Sie unter:{" "}
        <a href="https://telegram.org/privacy" target="_blank" rel="noopener noreferrer">
          Telegram Privacy Policy
        </a>
        .
      </p>

      <h2>5. Bestellabwicklung, Versand und Zahlung</h2>
      <p>
        Für die Abwicklung einer Bestellung geben wir die erforderlichen Daten an die beteiligten
        Dienstleister weiter (Art. 6 Abs. 1 lit. b DSGVO): Ihre Lieferadresse an das Versandunternehmen
        DHL sowie bei Zahlung per PayPal die für die Zahlungsabwicklung erforderlichen Daten an PayPal.
        Bei Zahlung per Banküberweisung verarbeiten wir die Zahlungsdaten, die uns Ihr Kreditinstitut
        übermittelt. Steuer- und handelsrechtliche Aufbewahrungsfristen bleiben unberührt.
      </p>

      <h2>6. Ihre Rechte</h2>
      <p>
        Sie haben jederzeit das Recht auf Auskunft über Herkunft, Empfänger und Zweck Ihrer gespeicherten
        personenbezogenen Daten sowie auf Berichtigung, Löschung, Einschränkung der Verarbeitung und
        Datenübertragbarkeit. Erteilte Einwilligungen können Sie jederzeit widerrufen, und Sie können der
        Verarbeitung auf Grundlage berechtigter Interessen widersprechen (Art. 21 DSGVO). Wenden Sie sich
        hierzu einfach an die im Impressum angegebene Adresse.
      </p>
      <p>
        Außerdem haben Sie das Recht, sich bei einer Datenschutz-Aufsichtsbehörde zu beschweren. Zuständig
        ist der Hessische Beauftragte für Datenschutz und Informationsfreiheit (HBDI), Wiesbaden,{" "}
        <a href="https://datenschutz.hessen.de" target="_blank" rel="noopener noreferrer">
          datenschutz.hessen.de
        </a>
        .
      </p>
      <p>Stand: Oktober 2026</p>
    </article>
  );
}
