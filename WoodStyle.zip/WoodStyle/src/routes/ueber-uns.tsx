import { createFileRoute } from "@tanstack/react-router";
import { Cta } from "@/components/cta";

export const Route = createFileRoute("/ueber-uns")({
  head: () => ({
    meta: [
      { title: "Über uns · WoodStyle" },
      {
        name: "description",
        content:
          "WoodStyle aus Weilburg: handgefertigte Holzprodukte und Brandmalerei, bei der die Maserung zum Motiv gehört.",
      },
    ],
  }),
  component: About,
});

function About() {
  return (
    <>
      <div className="mx-auto grid max-w-6xl items-end gap-10 px-5 pt-12 pb-8 md:px-8 md:pt-16 lg:grid-cols-12">
        <div className="lg:col-span-6">
          <p className="text-xs font-medium tracking-kicker text-ember uppercase">Über uns</p>
          <h1 className="mt-3 font-display text-section">Holz mit einer eigenen Handschrift</h1>
          <p className="mt-5 text-lg text-mute">
            Willkommen bei WoodStyle. Wir fertigen mit Geduld und Präzision Holzprodukte und Kunstwerke
            in traditioneller Brandmalerei — Pyrografie, das Zeichnen mit Hitze.
          </p>
        </div>
        <blockquote className="border-l-2 border-ember pl-6 font-display text-3xl lg:col-span-6">
          Jedes Stück trägt seine Maserung schon mit. Wir geben ihr nur das Motiv.
        </blockquote>
      </div>

      <div className="mx-auto max-w-6xl px-5 md:px-8">
        <img
          src="/images/atelier.jpg"
          alt="Werkstatt mit gestapelten Brettern, Werkzeug und einer fertigen Holztafel im Nachmittagslicht"
          width={1600}
          height={1067}
          className="aspect-video w-full rounded-xl object-cover"
        />
      </div>

      <div className="mx-auto grid max-w-6xl gap-12 px-5 py-16 md:grid-cols-12 md:px-8 md:py-20">
        <div className="md:col-span-7 md:col-start-1">
          <p className="text-lg text-mute">
            Bei der Fertigung achten wir darauf, die natürliche Schönheit des Holzes zu bewahren und sie
            durch ein individuelles Motiv zu veredeln. Nichts wird in Serie gedruckt. Die dunkle Linie
            sitzt im Material, nicht darauf.
          </p>
          <p className="mt-5 text-lg text-mute">
            Die Stücke sind für den täglichen Gebrauch gedacht und ebenso als persönliches Geschenk —
            für Familie, Freunde oder einen Anlass, zu dem ein Gegenstand mehr sagen soll als eine Karte.
          </p>
          <p className="mt-5 text-lg text-mute">
            Das Atelier steht in Weilburg. Anfragen laufen direkt, ohne Formularstrecke: Sie schicken
            Idee und Foto, wir antworten mit einem unverbindlichen Angebot.
          </p>
          <Cta to="/kontakt" className="mt-8">
            Gespräch beginnen
          </Cta>
        </div>
        <figure className="md:col-span-4 md:col-start-9">
          <img
            src="/images/grain.jpg"
            alt="Makroaufnahme eingebrannter Linien in heller Holzmaserung"
            width={1000}
            height={1000}
            loading="lazy"
            className="aspect-square w-full rounded-xl object-cover"
          />
          <figcaption className="mt-3 text-xs tracking-kicker text-mute uppercase">
            Die Linie bleibt im Holz
          </figcaption>
        </figure>
      </div>
    </>
  );
}
