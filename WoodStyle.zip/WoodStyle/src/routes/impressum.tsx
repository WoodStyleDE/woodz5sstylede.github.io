import { createFileRoute } from "@tanstack/react-router";
import { brand } from "@/lib/content";

export const Route = createFileRoute("/impressum")({
  head: () => ({
    meta: [
      { title: "Impressum · WoodStyle" },
      {
        name: "description",
        content: "Impressum von WoodStyle: Anbieterkennzeichnung und Kontaktdaten gemäß § 5 DDG.",
      },
    ],
  }),
  component: Impressum,
});

function Impressum() {
  return (
    <article className="legal mx-auto max-w-3xl px-5 pt-12 pb-20 md:px-8 md:pt-16">
      <p className="text-xs font-medium tracking-kicker text-ember uppercase">Rechtliches</p>
      <h1 className="mt-3 font-display text-section">Impressum</h1>

      <h2>Angaben gemäß § 5 DDG</h2>
      <p>
        <strong className="text-ink">{brand.owner}</strong>
        <br />
        {brand.name}
        <br />
        {brand.street}
        <br />
        {brand.zip} {brand.city}
        <br />
        {brand.country}
      </p>

      <h2>Kontakt</h2>
      <p>
        Telefon: <a href={`tel:${brand.phoneTel}`}>{brand.phonePretty}</a>
        <br />
        E-Mail: <a href={`mailto:${brand.email}`}>{brand.email}</a>
      </p>

      <h2>Umsatzsteuer</h2>
      <p>Gemäß § 19 UStG wird keine Umsatzsteuer berechnet und ausgewiesen (Kleinunternehmerregelung).</p>

      <h2>Redaktionell verantwortlich</h2>
      <p>
        {brand.owner}
        <br />
        {brand.street}
        <br />
        {brand.zip} {brand.city}
      </p>

      <h2>Verbraucherstreitbeilegung / Universalschlichtungsstelle</h2>
      <p>
        Wir sind nicht bereit oder verpflichtet, an Streitbeilegungsverfahren vor einer
        Verbraucherschlichtungsstelle teilzunehmen.
      </p>
    </article>
  );
}
