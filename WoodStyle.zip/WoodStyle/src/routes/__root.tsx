import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { SiteFooter, WhatsappFab } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";
import { Cta } from "@/components/cta";
import appCss from "../styles.css?url";

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "WoodStyle – Brandmalerei & Holzdesign aus Weilburg" },
      {
        name: "description",
        content:
          "Handgefertigte Brandmalerei und Holzdesign aus Weilburg: Porträts nach Foto, Schneidebretter, Untersetzer und kleine Unikate.",
      },
      { name: "theme-color", content: "#3a2a20" },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
    ],
  }),
  notFoundComponent: NotFound,
  component: RootComponent,
});

function RootComponent() {
  return (
    <html lang="de" className="antialiased" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body className="bg-paper font-sans text-ink">
        <PreviewHostBridge />
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:absolute focus:top-3 focus:left-3 focus:z-50 focus:rounded-full focus:bg-ember focus:px-4 focus:py-2 focus:text-paper"
        >
          Zum Inhalt springen
        </a>
        <AuthProvider>
          <div className="flex min-h-screen flex-col">
            <SiteHeader />
            <main id="main" className="flex-1 pb-20 md:pb-0">
              <Outlet />
            </main>
            <SiteFooter />
          </div>
          <WhatsappFab />
        </AuthProvider>
        <Scripts />
      </body>
    </html>
  );
}

function NotFound() {
  return (
    <div className="mx-auto max-w-xl px-5 py-24 md:px-8">
      <p className="font-display text-8xl text-ember">404</p>
      <h1 className="mt-4 font-display text-section">Diese Seite gibt es nicht</h1>
      <p className="mt-4 text-lg text-mute">
        Der Link ist veraltet oder die Adresse hat sich verschrieben.
      </p>
      <Cta to="/" className="mt-8">
        Zur Startseite
      </Cta>
    </div>
  );
}
